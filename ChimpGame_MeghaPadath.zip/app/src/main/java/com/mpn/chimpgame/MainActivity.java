package com.mpn.chimpgame;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private Spinner spinner;
    private static final String[] paths = {"2", "3", "4", "5"};
    public int clicked_btn [] = new int [3];
    int [] device_seq = new int[3];
    public int gobal_i = 0;
    public String start_color = "#212bde";
    public String mid_color = "#e8dd0c";
    public String picked_color = "#31e03d";
    public String err_color = "#ed070f";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = (Spinner) findViewById(R.id.delaySpinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_spinner_item, paths);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        Button check_btn = (Button)findViewById(R.id.check);
        check_btn.setEnabled(false);
    }

    public class SetPosition {

        public void btn_number1(int pos){
            Button B1 = (Button)findViewById(R.id.B1);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B1.setText(pos2);
            //B1.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number2(int pos){
            Button B2 = (Button)findViewById(R.id.B2);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B2.setText(pos2);
            //B2.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number3(int pos){
            Button B3 = (Button)findViewById(R.id.B3);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B3.setText(pos2);
            //B3.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number4(int pos){
            Button B4 = (Button)findViewById(R.id.B4);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B4.setText(pos2);
            //B4.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number5(int pos){
            Button B5 = (Button)findViewById(R.id.B5);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B5.setText(pos2);
            //B5.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number6(int pos){
            Button B6 = (Button)findViewById(R.id.B6);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B6.setText(pos2);
            //B6.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number7(int pos){
            Button B7 = (Button)findViewById(R.id.B7);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B7.setText(pos2);
            //B7.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number8(int pos){
            Button B8 = (Button)findViewById(R.id.B8);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B8.setText(pos2);
            //B8.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number9(int pos){
            Button B9 = (Button)findViewById(R.id.B9);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B9.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }

    }

    public class SetColortoButtons {
        public void btn_number1(String color){
            Button B1 = (Button)findViewById(R.id.B1);
            B1.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number2(String color){
            Button B2 = (Button)findViewById(R.id.B2);
            B2.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number3(String color){
            Button B3 = (Button)findViewById(R.id.B3);
            B3.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number4(String color){
            Button B4 = (Button)findViewById(R.id.B4);
            B4.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number5(String color){
            Button B5 = (Button)findViewById(R.id.B5);
            B5.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number6(String color){
            Button B6 = (Button)findViewById(R.id.B6);
            B6.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number7(String color){
            Button B7 = (Button)findViewById(R.id.B7);
            B7.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number8(String color){
            Button B8 = (Button)findViewById(R.id.B8);
            B8.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number9(String color){
            Button B9 = (Button)findViewById(R.id.B9);
            B9.setBackgroundColor(Color.parseColor(color));
        }
    }

    public int generateRandomNumber(View v){
        int Min = 1;
        int Max = 9;
        Random rand = new Random();
        int rand_int1 = rand.nextInt((Max - Min)+1)+Min;
        return rand_int1;
    }

    public boolean checkValueinArray(View v,int[] arr, int checkValueNumber){
        String status = "Not Found";
        for(int element : arr){
            if(element == checkValueNumber){
                status = "Found";
                break;
            }
        }
        if(status == "Not Found"){
            return false;
        }
        else
            return true;
    }

    public void delay(final int c){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(c);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // sendData("S");
                Button B1 = (Button)findViewById(R.id.B1);
                Button B2 = (Button)findViewById(R.id.B2);
                Button B3 = (Button)findViewById(R.id.B3);
                Button B4 = (Button)findViewById(R.id.B4);
                Button B5 = (Button)findViewById(R.id.B5);
                Button B6 = (Button)findViewById(R.id.B6);
                Button B7 = (Button)findViewById(R.id.B7);
                Button B8 = (Button)findViewById(R.id.B8);
                Button B9 = (Button)findViewById(R.id.B9);
                B1.setText("");
                B2.setText("");
                B3.setText("");
                B4.setText("");
                B5.setText("");
                B6.setText("");
                B7.setText("");
                B8.setText("");
                B9.setText("");

                SetColortoButtons scb = new SetColortoButtons();

                scb.btn_number1(start_color);
                scb.btn_number2(start_color);
                scb.btn_number3(start_color);
                scb.btn_number4(start_color);
                scb.btn_number5(start_color);
                scb.btn_number6(start_color);
                scb.btn_number7(start_color);
                scb.btn_number8(start_color);
                scb.btn_number9(start_color);
            }
        }, c);

    }

    public void onStartGame(View v) {
        Button B1 = (Button)findViewById(R.id.B1);
        Button B2 = (Button)findViewById(R.id.B2);
        Button B3 = (Button)findViewById(R.id.B3);
        Button B4 = (Button)findViewById(R.id.B4);
        Button B5 = (Button)findViewById(R.id.B5);
        Button B6 = (Button)findViewById(R.id.B6);
        Button B7 = (Button)findViewById(R.id.B7);
        Button B8 = (Button)findViewById(R.id.B8);
        Button B9 = (Button)findViewById(R.id.B9);
        Spinner delay = (Spinner)findViewById(R.id.delaySpinner);

        B1.setText("");
        B2.setText("");
        B3.setText("");
        B4.setText("");
        B5.setText("");
        B6.setText("");
        B7.setText("");
        B8.setText("");
        B9.setText("");

        SetColortoButtons scb = new SetColortoButtons();

        scb.btn_number1(start_color);
        scb.btn_number2(start_color);
        scb.btn_number3(start_color);
        scb.btn_number4(start_color);
        scb.btn_number5(start_color);
        scb.btn_number6(start_color);
        scb.btn_number7(start_color);
        scb.btn_number8(start_color);
        scb.btn_number9(start_color);

        String delay_time = delay.getSelectedItem().toString();

        //int [] device_seq = new int[3];
        String[] dev = new String[3];
        int rand_number;
        int sub;
        boolean statusCheck;
        SetPosition sp = new SetPosition();
        B1.setEnabled(true);
        B2.setEnabled(true);
        B3.setEnabled(true);
        B4.setEnabled(true);
        B5.setEnabled(true);
        B6.setEnabled(true);
        B7.setEnabled(true);
        B8.setEnabled(true);
        B9.setEnabled(true);
        gobal_i = 0;
        for(int i =0; i<3; i++){
            clicked_btn[i] = 0;
        }

        for(int i = 0; i<3; i++){
            //Log.e("Counte_i","Ittration : "+i);
            if(i == 0){
                rand_number = generateRandomNumber(v);
                if(rand_number == 0){
                    device_seq[i] = 1;
                }
                else{
                    device_seq[i] = rand_number;
                }

            }
            else{
                boolean counter = false;
                boolean subCounter = false;
                while(!counter){
                    rand_number = generateRandomNumber(v);
                    while (!subCounter){
                        if(rand_number != 0){
                            //Log.e("Subcounter","rand_Number : "+rand_number);
                            subCounter = true;
                        }
                        else
                            //Log.e("Subcounter","Zero Found rand_Number : "+rand_number);
                            sub = 1;
                    }
                    statusCheck = checkValueinArray(v,device_seq, rand_number);
                    if(!statusCheck){
                        //Log.e("In_Array","Element no "+i+" : "+rand_number);
                        device_seq[i] = rand_number;
                        counter = true;
                    }

                    else {
                        //Log.e("In_Array","Element no "+i+" : "+rand_number);
                        counter = false;
                    }
                }
            }
        }

        for(int i =0; i<3; i++){
            //Log.e("Counte_i","Ittration : "+i);
            String e1 = String.valueOf(device_seq[i]);
            //String e2 = "B"+e1;
            dev[i] = e1;
            int pos = i;
            //Log.e("Pos","Pos : "+e1);
            if(device_seq[i] == 1){
                pos++;
                sp.btn_number1(pos);
                scb.btn_number1(mid_color);
            }
            else if(device_seq[i] == 2){
                pos++;
                sp.btn_number2(pos);
                scb.btn_number2(mid_color);
            }
            else if(device_seq[i] == 3){
                pos++;
                sp.btn_number3(pos);
                scb.btn_number3(mid_color);
            }
            else if(device_seq[i] == 4){
                pos++;
                sp.btn_number4(pos);
                scb.btn_number4(mid_color);
            }
            else if(device_seq[i] == 5){
                pos++;
                sp.btn_number5(pos);
                scb.btn_number5(mid_color);
            }
            else if(device_seq[i] == 6){
                pos++;
                sp.btn_number6(pos);
                scb.btn_number6(mid_color);
            }
            else if(device_seq[i] == 7){
                pos++;
                sp.btn_number7(pos);
                scb.btn_number7(mid_color);
            }
            else if(device_seq[i] == 8){
                pos++;
                sp.btn_number8(pos);
                scb.btn_number8(mid_color);
            }
            else if(device_seq[i] == 9){
                pos++;
                sp.btn_number9(pos);
                scb.btn_number9(mid_color);
            }


        }

        int delatTime = Integer.parseInt(delay_time);
        int add = delatTime * 1000;

        delay(add);
    }

    public void check_arr_Full(View v){
        if(clicked_btn[0] !=0 && clicked_btn[1] !=0 && clicked_btn[2]!=0){
            Button check_btn = (Button)findViewById(R.id.check);
            check_btn.setEnabled(true);
            Button B1 = (Button)findViewById(R.id.B1);
            B1.setEnabled(false);
            Button B2 = (Button)findViewById(R.id.B2);
            B2.setEnabled(false);
            Button B3 = (Button)findViewById(R.id.B3);
            B3.setEnabled(false);
            Button B4 = (Button)findViewById(R.id.B4);
            B4.setEnabled(false);
            Button B5 = (Button)findViewById(R.id.B5);
            B5.setEnabled(false);
            Button B6 = (Button)findViewById(R.id.B6);
            B6.setEnabled(false);
            Button B7 = (Button)findViewById(R.id.B7);
            B7.setEnabled(false);
            Button B8 = (Button)findViewById(R.id.B8);
            B8.setEnabled(false);
            Button B9 = (Button)findViewById(R.id.B9);
            B9.setEnabled(false);
        }
    }

    public void onClickCheck (View v){
        SetColortoButtons scb = new SetColortoButtons();
        SetPosition sp = new SetPosition();
        switch (v.getId()){
            case R.id.B1:
                clicked_btn[gobal_i] = 1;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number1(picked_color);
                sp.btn_number1(gobal_i);
                break;
            case R.id.B2:
                clicked_btn[gobal_i] = 2;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number2(picked_color);
                sp.btn_number2(gobal_i);
                break;
            case R.id.B3:
                clicked_btn[gobal_i] = 3;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number3(picked_color);
                sp.btn_number3(gobal_i);
                break;
            case R.id.B4:
                clicked_btn[gobal_i] = 4;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number4(picked_color);
                sp.btn_number4(gobal_i);
                break;
            case R.id.B5:
                clicked_btn[gobal_i] = 5;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number5(picked_color);
                sp.btn_number5(gobal_i);
                break;
            case R.id.B6:
                clicked_btn[gobal_i] = 6;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number6(picked_color);
                sp.btn_number6(gobal_i);
                break;
            case R.id.B7:
                clicked_btn[gobal_i] = 7;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number7(picked_color);
                sp.btn_number7(gobal_i);
                break;
            case R.id.B8:
                clicked_btn[gobal_i] = 8;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number8(picked_color);
                sp.btn_number8(gobal_i);
                break;
            default:
                clicked_btn[gobal_i] = 9;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number9(picked_color);
                sp.btn_number9(gobal_i);
                break;
        }

    }

    public void checkResult(View v){
        TextView tv_result = (TextView)findViewById(R.id.Result);
        SetColortoButtons scb = new SetColortoButtons();
        SetPosition sp = new SetPosition();
        int counter = 0;
        int didnotmatct [] = new int[3];
        for(int i = 0; i<3; i++){
            //String device_value = String.valueOf(device_seq[i]);
            //String user_value = String.valueOf(clicked_btn[i]);
            //Log.e("Device_Numbers",i+"  = "+device_value);
            //Log.e("User_Numbers",i+"  = "+user_value);
            if(device_seq[i] != clicked_btn[i]){
                tv_result.setText("You Lost");
                counter++;
                if(device_seq[i] == 1){
                    scb.btn_number1(mid_color);
                }
                else if(device_seq[i] == 2){
                    scb.btn_number2(mid_color);
                }
                else if(device_seq[i] == 3){
                    scb.btn_number3(mid_color);
                }
                else if(device_seq[i] == 4){
                    scb.btn_number4(mid_color);
                }
                else if(device_seq[i] == 5){
                    scb.btn_number5(mid_color);
                }
                else if(device_seq[i] == 6){
                    scb.btn_number6(mid_color);
                }
                else if(device_seq[i] == 7){
                    scb.btn_number7(mid_color);
                }
                else if(device_seq[i] == 8){
                    scb.btn_number8(mid_color);
                }
                else if(device_seq[i] == 9){
                    scb.btn_number9(mid_color);
                }
            }
            else{
                if(counter != 0){
                    tv_result.setText("You Lost");
                }
                else {
                    tv_result.setText("You Won!!!!!!!!!!!!!!");
                }

            }
        }

    }

}