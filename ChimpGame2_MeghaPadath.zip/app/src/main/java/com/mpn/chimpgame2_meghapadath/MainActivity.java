package com.mpn.chimpgame2_meghapadath;


import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    public int clicked_btn [] = new int [10];
    int [] device_seq = new int[10];
    public int gobal_i = 0;
    public String start_color = "#212bde";
    public String mid_color = "#e8dd0c";
    public String picked_color = "#31e03d";
    public String err_color = "#ed070f";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public class SetPosition {

        public void btn_number1(int pos){
            Button B1 = (Button)findViewById(R.id.B1);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B1.setText(pos2);
            //B1.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number2(int pos){
            Button B2 = (Button)findViewById(R.id.B2);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B2.setText(pos2);
            //B2.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number3(int pos){
            Button B3 = (Button)findViewById(R.id.B3);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B3.setText(pos2);
            //B3.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number4(int pos){
            Button B4 = (Button)findViewById(R.id.B4);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B4.setText(pos2);
            //B4.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number5(int pos){
            Button B5 = (Button)findViewById(R.id.B5);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B5.setText(pos2);
            //B5.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number6(int pos){
            Button B6 = (Button)findViewById(R.id.B6);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B6.setText(pos2);
            //B6.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number7(int pos){
            Button B7 = (Button)findViewById(R.id.B7);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B7.setText(pos2);
            //B7.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number8(int pos){
            Button B8 = (Button)findViewById(R.id.B8);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B8.setText(pos2);
            //B8.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number9(int pos){
            Button B9 = (Button)findViewById(R.id.B9);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B9.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number10(int pos){
            Button B10 = (Button)findViewById(R.id.B10);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B10.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number11(int pos){
            Button B11 = (Button)findViewById(R.id.B11);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B11.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number12(int pos){
            Button B12 = (Button)findViewById(R.id.B12);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B12.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number13(int pos){
            Button B13 = (Button)findViewById(R.id.B13);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B13.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number14(int pos){
            Button B14 = (Button)findViewById(R.id.B14);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B14.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number15(int pos){
            Button B15 = (Button)findViewById(R.id.B15);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B15.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number16(int pos){
            Button B16 = (Button)findViewById(R.id.B16);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B16.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number17(int pos){
            Button B17 = (Button)findViewById(R.id.B17);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B17.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number18(int pos){
            Button B18 = (Button)findViewById(R.id.B18);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B18.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number19(int pos){
            Button B19 = (Button)findViewById(R.id.B19);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B19.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }
        public void btn_number20(int pos){
            Button B20 = (Button)findViewById(R.id.B20);
            int pos1 = pos;
            String pos2 = String.valueOf(pos1);
            B20.setText(pos2);
            //B9.setBackgroundColor(Color.parseColor("#04b810"));
        }

    }

    public class SetColortoButtons {
        public void btn_number1(String color){
            Button B1 = (Button)findViewById(R.id.B1);
            B1.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number2(String color){
            Button B2 = (Button)findViewById(R.id.B2);
            B2.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number3(String color){
            Button B3 = (Button)findViewById(R.id.B3);
            B3.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number4(String color){
            Button B4 = (Button)findViewById(R.id.B4);
            B4.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number5(String color){
            Button B5 = (Button)findViewById(R.id.B5);
            B5.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number6(String color){
            Button B6 = (Button)findViewById(R.id.B6);
            B6.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number7(String color){
            Button B7 = (Button)findViewById(R.id.B7);
            B7.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number8(String color){
            Button B8 = (Button)findViewById(R.id.B8);
            B8.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number9(String color){
            Button B9 = (Button)findViewById(R.id.B9);
            B9.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number10(String color){
            Button B10 = (Button)findViewById(R.id.B10);
            B10.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number11(String color){
            Button B11 = (Button)findViewById(R.id.B11);
            B11.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number12(String color){
            Button B12 = (Button)findViewById(R.id.B12);
            B12.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number13(String color){
            Button B13 = (Button)findViewById(R.id.B13);
            B13.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number14(String color){
            Button B14 = (Button)findViewById(R.id.B14);
            B14.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number15(String color){
            Button B15 = (Button)findViewById(R.id.B15);
            B15.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number16(String color){
            Button B16 = (Button)findViewById(R.id.B16);
            B16.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number17(String color){
            Button B17 = (Button)findViewById(R.id.B17);
            B17.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number18(String color){
            Button B18 = (Button)findViewById(R.id.B18);
            B18.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number19(String color){
            Button B19 = (Button)findViewById(R.id.B19);
            B19.setBackgroundColor(Color.parseColor(color));
        }
        public void btn_number20(String color){
            Button B20 = (Button)findViewById(R.id.B20);
            B20.setBackgroundColor(Color.parseColor(color));
        }
    }

    public int generateRandomNumber(View v){
        int Min = 1;
        int Max = 20;
        Random rand = new Random();
        int rand_int1 = rand.nextInt((Max - Min)+1)+Min;
        return rand_int1;
    }

    public boolean checkValueinArray(View v,int[] arr, int checkValueNumber){
        String status = "Not Found";
        for(int element : arr){
            if(element == checkValueNumber){
                status = "Found";
                break;
            }
        }
        if(status == "Not Found"){
            return false;
        }
        else
            return true;
    }

    public void delay(View v){
        Button B1 = (Button)findViewById(R.id.B1);
        Button B2 = (Button)findViewById(R.id.B2);
        Button B3 = (Button)findViewById(R.id.B3);
        Button B4 = (Button)findViewById(R.id.B4);
        Button B5 = (Button)findViewById(R.id.B5);
        Button B6 = (Button)findViewById(R.id.B6);
        Button B7 = (Button)findViewById(R.id.B7);
        Button B8 = (Button)findViewById(R.id.B8);
        Button B9 = (Button)findViewById(R.id.B9);
        Button B10 = (Button)findViewById(R.id.B10);
        Button B11 = (Button)findViewById(R.id.B11);
        Button B12 = (Button)findViewById(R.id.B12);
        Button B13 = (Button)findViewById(R.id.B13);
        Button B14 = (Button)findViewById(R.id.B14);
        Button B15 = (Button)findViewById(R.id.B15);
        Button B16 = (Button)findViewById(R.id.B16);
        Button B17 = (Button)findViewById(R.id.B17);
        Button B18 = (Button)findViewById(R.id.B18);
        Button B19 = (Button)findViewById(R.id.B19);
        Button B20 = (Button)findViewById(R.id.B20);


        B1.setText("");
        B2.setText("");
        B3.setText("");
        B4.setText("");
        B5.setText("");
        B6.setText("");
        B7.setText("");
        B8.setText("");
        B9.setText("");
        B10.setText("");
        B11.setText("");
        B12.setText("");
        B13.setText("");
        B14.setText("");
        B15.setText("");
        B16.setText("");
        B17.setText("");
        B18.setText("");
        B19.setText("");
        B20.setText("");

        SetColortoButtons scb = new SetColortoButtons();

        scb.btn_number1(start_color);
        scb.btn_number2(start_color);
        scb.btn_number3(start_color);
        scb.btn_number4(start_color);
        scb.btn_number5(start_color);
        scb.btn_number6(start_color);
        scb.btn_number7(start_color);
        scb.btn_number8(start_color);
        scb.btn_number9(start_color);
        scb.btn_number10(start_color);
        scb.btn_number11(start_color);
        scb.btn_number12(start_color);
        scb.btn_number13(start_color);
        scb.btn_number14(start_color);
        scb.btn_number15(start_color);
        scb.btn_number16(start_color);
        scb.btn_number17(start_color);
        scb.btn_number18(start_color);
        scb.btn_number19(start_color);
        scb.btn_number20(start_color);

    }

    public void onStartGame(View v) {
        Button B1 = (Button)findViewById(R.id.B1);
        Button B2 = (Button)findViewById(R.id.B2);
        Button B3 = (Button)findViewById(R.id.B3);
        Button B4 = (Button)findViewById(R.id.B4);
        Button B5 = (Button)findViewById(R.id.B5);
        Button B6 = (Button)findViewById(R.id.B6);
        Button B7 = (Button)findViewById(R.id.B7);
        Button B8 = (Button)findViewById(R.id.B8);
        Button B9 = (Button)findViewById(R.id.B9);
        Button B10 = (Button)findViewById(R.id.B10);
        Button B11 = (Button)findViewById(R.id.B11);
        Button B12 = (Button)findViewById(R.id.B12);
        Button B13 = (Button)findViewById(R.id.B13);
        Button B14 = (Button)findViewById(R.id.B14);
        Button B15 = (Button)findViewById(R.id.B15);
        Button B16 = (Button)findViewById(R.id.B16);
        Button B17 = (Button)findViewById(R.id.B17);
        Button B18 = (Button)findViewById(R.id.B18);
        Button B19 = (Button)findViewById(R.id.B19);
        Button B20 = (Button)findViewById(R.id.B20);


        B1.setText("");
        B2.setText("");
        B3.setText("");
        B4.setText("");
        B5.setText("");
        B6.setText("");
        B7.setText("");
        B8.setText("");
        B9.setText("");
        B10.setText("");
        B11.setText("");
        B12.setText("");
        B13.setText("");
        B14.setText("");
        B15.setText("");
        B16.setText("");
        B17.setText("");
        B18.setText("");
        B19.setText("");
        B20.setText("");

        SetColortoButtons scb = new SetColortoButtons();

        scb.btn_number1(start_color);
        scb.btn_number2(start_color);
        scb.btn_number3(start_color);
        scb.btn_number4(start_color);
        scb.btn_number5(start_color);
        scb.btn_number6(start_color);
        scb.btn_number7(start_color);
        scb.btn_number8(start_color);
        scb.btn_number9(start_color);
        scb.btn_number10(start_color);
        scb.btn_number11(start_color);
        scb.btn_number12(start_color);
        scb.btn_number13(start_color);
        scb.btn_number14(start_color);
        scb.btn_number15(start_color);
        scb.btn_number16(start_color);
        scb.btn_number17(start_color);
        scb.btn_number18(start_color);
        scb.btn_number19(start_color);
        scb.btn_number20(start_color);

        //int [] device_seq = new int[10];
        String[] dev = new String[10];
        int rand_number;
        int sub;
        boolean statusCheck;
        SetPosition sp = new SetPosition();
        B1.setEnabled(true);
        B2.setEnabled(true);
        B3.setEnabled(true);
        B4.setEnabled(true);
        B5.setEnabled(true);
        B6.setEnabled(true);
        B7.setEnabled(true);
        B8.setEnabled(true);
        B9.setEnabled(true);
        B10.setEnabled(true);
        B11.setEnabled(true);
        B12.setEnabled(true);
        B13.setEnabled(true);
        B14.setEnabled(true);
        B15.setEnabled(true);
        B16.setEnabled(true);
        B17.setEnabled(true);
        B18.setEnabled(true);
        B19.setEnabled(true);
        B20.setEnabled(true);
        gobal_i = 0;
        for(int i =0; i<10; i++){
            clicked_btn[i] = 0;
        }

        for(int i = 0; i<10; i++){
            //Log.e("Counte_i","Ittration : "+i);
            if(i == 0){
                rand_number = generateRandomNumber(v);
                if(rand_number == 0){
                    device_seq[i] = 1;
                }
                else{
                    device_seq[i] = rand_number;
                }

            }
            else{
                boolean counter = false;
                boolean subCounter = false;
                while(!counter){
                    rand_number = generateRandomNumber(v);
                    while (!subCounter){
                        if(rand_number != 0){
                            //Log.e("Subcounter","rand_Number : "+rand_number);
                            subCounter = true;
                        }
                        else
                            //Log.e("Subcounter","Zero Found rand_Number : "+rand_number);
                            sub = 1;
                    }
                    statusCheck = checkValueinArray(v,device_seq, rand_number);
                    if(!statusCheck){
                        //Log.e("In_Array","Element no "+i+" : "+rand_number);
                        device_seq[i] = rand_number;
                        counter = true;
                    }

                    else {
                        //Log.e("In_Array","Element no "+i+" : "+rand_number);
                        counter = false;
                    }
                }
            }
        }

        for(int i =0; i<10; i++){
            //Log.e("Counte_i","Ittration : "+i);
            String e1 = String.valueOf(device_seq[i]);
            //String e2 = "B"+e1;
            dev[i] = e1;
            int pos = i;
            //Log.e("Pos","Pos : "+e1);
            if(device_seq[i] == 1){
                pos++;
                sp.btn_number1(pos);
                scb.btn_number1(mid_color);
            }
            else if(device_seq[i] == 2){
                pos++;
                sp.btn_number2(pos);
                scb.btn_number2(mid_color);
            }
            else if(device_seq[i] == 3){
                pos++;
                sp.btn_number3(pos);
                scb.btn_number3(mid_color);
            }
            else if(device_seq[i] == 4){
                pos++;
                sp.btn_number4(pos);
                scb.btn_number4(mid_color);
            }
            else if(device_seq[i] == 5){
                pos++;
                sp.btn_number5(pos);
                scb.btn_number5(mid_color);
            }
            else if(device_seq[i] == 6){
                pos++;
                sp.btn_number6(pos);
                scb.btn_number6(mid_color);
            }
            else if(device_seq[i] == 7){
                pos++;
                sp.btn_number7(pos);
                scb.btn_number7(mid_color);
            }
            else if(device_seq[i] == 8){
                pos++;
                sp.btn_number8(pos);
                scb.btn_number8(mid_color);
            }
            else if(device_seq[i] == 9){
                pos++;
                sp.btn_number9(pos);
                scb.btn_number9(mid_color);
            }
            else if(device_seq[i] == 10){
                pos++;
                sp.btn_number10(pos);
                scb.btn_number10(mid_color);
            }
            else if(device_seq[i] == 11){
                pos++;
                sp.btn_number11(pos);
                scb.btn_number11(mid_color);
            }
            else if(device_seq[i] == 12){
                pos++;
                sp.btn_number12(pos);
                scb.btn_number12(mid_color);
            }
            else if(device_seq[i] == 13){
                pos++;
                sp.btn_number13(pos);
                scb.btn_number13(mid_color);
            }
            else if(device_seq[i] == 14){
                pos++;
                sp.btn_number14(pos);
                scb.btn_number14(mid_color);
            }
            else if(device_seq[i] == 15){
                pos++;
                sp.btn_number15(pos);
                scb.btn_number15(mid_color);
            }
            else if(device_seq[i] == 16){
                pos++;
                sp.btn_number16(pos);
                scb.btn_number16(mid_color);
            }
            else if(device_seq[i] == 17){
                pos++;
                sp.btn_number17(pos);
                scb.btn_number17(mid_color);
            }
            else if(device_seq[i] == 18){
                pos++;
                sp.btn_number18(pos);
                scb.btn_number18(mid_color);
            }
            else if(device_seq[i] == 19){
                pos++;
                sp.btn_number19(pos);
                scb.btn_number19(mid_color);
            }
            else if(device_seq[i] == 20){
                pos++;
                sp.btn_number20(pos);
                scb.btn_number20(mid_color);
            }



        }


    }

    public void check_arr_Full(View v){
        if(clicked_btn[0] !=0 && clicked_btn[1] !=0 && clicked_btn[2]!=0 && clicked_btn[3]!=0 && clicked_btn[4]!=0 && clicked_btn[5]!=0 && clicked_btn[6]!=0 && clicked_btn[7]!=0 && clicked_btn[8]!=0 && clicked_btn[9]!=0){
            Button check_btn = (Button)findViewById(R.id.Result);
            check_btn.setEnabled(true);
            Button B1 = (Button)findViewById(R.id.B1);
            B1.setEnabled(false);
            Button B2 = (Button)findViewById(R.id.B2);
            B2.setEnabled(false);
            Button B3 = (Button)findViewById(R.id.B3);
            B3.setEnabled(false);
            Button B4 = (Button)findViewById(R.id.B4);
            B4.setEnabled(false);
            Button B5 = (Button)findViewById(R.id.B5);
            B5.setEnabled(false);
            Button B6 = (Button)findViewById(R.id.B6);
            B6.setEnabled(false);
            Button B7 = (Button)findViewById(R.id.B7);
            B7.setEnabled(false);
            Button B8 = (Button)findViewById(R.id.B8);
            B8.setEnabled(false);
            Button B9 = (Button)findViewById(R.id.B9);
            B9.setEnabled(false);
            Button B10 = (Button)findViewById(R.id.B10);
            B10.setEnabled(false);
            Button B11 = (Button)findViewById(R.id.B11);
            B11.setEnabled(false);
            Button B12 = (Button)findViewById(R.id.B12);
            B12.setEnabled(false);
            Button B13 = (Button)findViewById(R.id.B13);
            B13.setEnabled(false);
            Button B14 = (Button)findViewById(R.id.B14);
            B14.setEnabled(false);
            Button B15 = (Button)findViewById(R.id.B15);
            B15.setEnabled(false);
            Button B16 = (Button)findViewById(R.id.B16);
            B16.setEnabled(false);
            Button B17 = (Button)findViewById(R.id.B17);
            B17.setEnabled(false);
            Button B18 = (Button)findViewById(R.id.B18);
            B18.setEnabled(false);
            Button B19 = (Button)findViewById(R.id.B1);
            B19.setEnabled(false);
            Button B20 = (Button)findViewById(R.id.B20);
            B20.setEnabled(false);
        }
    }

    public void onClickCheck (View v){
        SetColortoButtons scb = new SetColortoButtons();
        SetPosition sp = new SetPosition();
        switch (v.getId()){
            case R.id.B1:
                clicked_btn[gobal_i] = 1;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number1(picked_color);
                sp.btn_number1(gobal_i);
                break;
            case R.id.B2:
                clicked_btn[gobal_i] = 2;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number2(picked_color);
                sp.btn_number2(gobal_i);
                break;
            case R.id.B3:
                clicked_btn[gobal_i] = 3;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number3(picked_color);
                sp.btn_number3(gobal_i);
                break;
            case R.id.B4:
                clicked_btn[gobal_i] = 4;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number4(picked_color);
                sp.btn_number4(gobal_i);
                break;
            case R.id.B5:
                clicked_btn[gobal_i] = 5;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number5(picked_color);
                sp.btn_number5(gobal_i);
                break;
            case R.id.B6:
                clicked_btn[gobal_i] = 6;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number6(picked_color);
                sp.btn_number6(gobal_i);
                break;
            case R.id.B7:
                clicked_btn[gobal_i] = 7;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number7(picked_color);
                sp.btn_number7(gobal_i);
                break;
            case R.id.B8:
                clicked_btn[gobal_i] = 8;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number8(picked_color);
                sp.btn_number8(gobal_i);
                break;
            case R.id.B9:
                clicked_btn[gobal_i] = 9;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number9(picked_color);
                sp.btn_number9(gobal_i);
                break;
            case R.id.B10:
                clicked_btn[gobal_i] = 10;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number10(picked_color);
                sp.btn_number10(gobal_i);
                break;
            case R.id.B11:
                clicked_btn[gobal_i] = 11;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number11(picked_color);
                sp.btn_number11(gobal_i);
                break;
            case R.id.B12:
                clicked_btn[gobal_i] = 12;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number12(picked_color);
                sp.btn_number12(gobal_i);
                break;
            case R.id.B13:
                clicked_btn[gobal_i] = 13;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number13(picked_color);
                sp.btn_number13(gobal_i);
                break;
            case R.id.B14:
                clicked_btn[gobal_i] = 14;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number14(picked_color);
                sp.btn_number14(gobal_i);
                break;
            case R.id.B15:
                clicked_btn[gobal_i] = 15;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number15(picked_color);
                sp.btn_number15(gobal_i);
                break;
            case R.id.B16:
                clicked_btn[gobal_i] = 16;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number16(picked_color);
                sp.btn_number16(gobal_i);
                break;
            case R.id.B17:
                clicked_btn[gobal_i] = 17;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number17(picked_color);
                sp.btn_number17(gobal_i);
                break;
            case R.id.B18:
                clicked_btn[gobal_i] = 18;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number18(picked_color);
                sp.btn_number18(gobal_i);
                break;
            case R.id.B19:
                clicked_btn[gobal_i] = 19;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number19(picked_color);
                sp.btn_number19(gobal_i);
                break;
            case R.id.B20:
                clicked_btn[gobal_i] = 20;
                gobal_i++;
                check_arr_Full(v);
                scb.btn_number20(picked_color);
                sp.btn_number20(gobal_i);
                break;
        }

    }

    public void checkResult(View v){
        TextView tv_result = (TextView)findViewById(R.id.Result);
        SetColortoButtons scb = new SetColortoButtons();
        SetPosition sp = new SetPosition();
        int counter = 0;
        int didnotmatct [] = new int[10];
        for(int i = 0; i<10; i++){
            //String device_value = String.valueOf(device_seq[i]);
            //String user_value = String.valueOf(clicked_btn[i]);
            //Log.e("Device_Numbers",i+"  = "+device_value);
            //Log.e("User_Numbers",i+"  = "+user_value);
            if(device_seq[i] != clicked_btn[i]){
                tv_result.setText("You Lost");
                counter++;
                if(device_seq[i] == 1){
                    scb.btn_number1(mid_color);
                }
                else if(device_seq[i] == 2){
                    scb.btn_number2(mid_color);
                }
                else if(device_seq[i] == 3){
                    scb.btn_number3(mid_color);
                }
                else if(device_seq[i] == 4){
                    scb.btn_number4(mid_color);
                }
                else if(device_seq[i] == 5){
                    scb.btn_number5(mid_color);
                }
                else if(device_seq[i] == 6){
                    scb.btn_number6(mid_color);
                }
                else if(device_seq[i] == 7){
                    scb.btn_number7(mid_color);
                }
                else if(device_seq[i] == 8){
                    scb.btn_number8(mid_color);
                }
                else if(device_seq[i] == 9){
                    scb.btn_number9(mid_color);
                }
                else if(device_seq[i] == 10){
                    scb.btn_number10(mid_color);
                }
                else if(device_seq[i] == 11){
                    scb.btn_number11(mid_color);
                }
                else if(device_seq[i] == 12){
                    scb.btn_number12(mid_color);
                }
                else if(device_seq[i] == 13){
                    scb.btn_number13(mid_color);
                }
                else if(device_seq[i] == 14){
                    scb.btn_number14(mid_color);
                }
                else if(device_seq[i] == 15){
                    scb.btn_number15(mid_color);
                }
                else if(device_seq[i] == 16){
                    scb.btn_number16(mid_color);
                }
                else if(device_seq[i] == 17){
                    scb.btn_number17(mid_color);
                }
                else if(device_seq[i] == 18){
                    scb.btn_number18(mid_color);
                }
                else if(device_seq[i] == 19){
                    scb.btn_number19(mid_color);
                }
                else if(device_seq[i] == 20){
                    scb.btn_number20(mid_color);
                }
            }
            else{
                if(counter != 0){
                    tv_result.setText("You Lost");
                }
                else {
                    tv_result.setText("You Won!!!!!!!!!!!!!!");
                }

            }
        }

    }

}